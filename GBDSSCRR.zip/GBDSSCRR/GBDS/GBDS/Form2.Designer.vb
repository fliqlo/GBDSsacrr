﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.RhlLbl = New System.Windows.Forms.Label()
        Me.RhlTxt = New System.Windows.Forms.TextBox()
        Me.RhpTxt = New System.Windows.Forms.TextBox()
        Me.RhpLbl = New System.Windows.Forms.Label()
        Me.PlTxt = New System.Windows.Forms.TextBox()
        Me.RhsTxt = New System.Windows.Forms.TextBox()
        Me.SmlbTxt = New System.Windows.Forms.TextBox()
        Me.Pp320Txt = New System.Windows.Forms.TextBox()
        Me.MhtTxt = New System.Windows.Forms.TextBox()
        Me.FbTxt = New System.Windows.Forms.TextBox()
        Me.CbTxt = New System.Windows.Forms.TextBox()
        Me.MhtBottTxt = New System.Windows.Forms.TextBox()
        Me.FbcTxt = New System.Windows.Forms.TextBox()
        Me.CnbTxt = New System.Windows.Forms.TextBox()
        Me.CcTxt = New System.Windows.Forms.TextBox()
        Me.PpcTxt = New System.Windows.Forms.TextBox()
        Me.GekTxt = New System.Windows.Forms.TextBox()
        Me.PlLbl = New System.Windows.Forms.Label()
        Me.RhsLbl = New System.Windows.Forms.Label()
        Me.SmlbLbl = New System.Windows.Forms.Label()
        Me.Pp320Lbl = New System.Windows.Forms.Label()
        Me.MhtLbl = New System.Windows.Forms.Label()
        Me.FbLbl = New System.Windows.Forms.Label()
        Me.CbLbl = New System.Windows.Forms.Label()
        Me.MhtBottLbl = New System.Windows.Forms.Label()
        Me.FbcLbl = New System.Windows.Forms.Label()
        Me.CnbLbl = New System.Windows.Forms.Label()
        Me.CcLbl = New System.Windows.Forms.Label()
        Me.PpcLbl = New System.Windows.Forms.Label()
        Me.GekLbl = New System.Windows.Forms.Label()
        Me.RhslTxt = New System.Windows.Forms.TextBox()
        Me.PlBottTxt = New System.Windows.Forms.TextBox()
        Me.FbBottTxt = New System.Windows.Forms.TextBox()
        Me.RhslBottTxt = New System.Windows.Forms.TextBox()
        Me.ChocLagTxt = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.RhslLbl = New System.Windows.Forms.Label()
        Me.PlBottLbl = New System.Windows.Forms.Label()
        Me.FbBottLbl = New System.Windows.Forms.Label()
        Me.RhslBottLbl = New System.Windows.Forms.Label()
        Me.ChocLagLbl = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.PpCompTxt = New System.Windows.Forms.TextBox()
        Me.PpShellTxt = New System.Windows.Forms.TextBox()
        Me.PpBottleTxt = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.RhlBottleTxt = New System.Windows.Forms.TextBox()
        Me.RhlShellTxt = New System.Windows.Forms.TextBox()
        Me.RhlCompTxt = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.RhpBottleTxt = New System.Windows.Forms.TextBox()
        Me.RhpShellTxt = New System.Windows.Forms.TextBox()
        Me.RhpCompTxt = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.FbaBottleTxt = New System.Windows.Forms.TextBox()
        Me.FbaShellTxt = New System.Windows.Forms.TextBox()
        Me.FbaCompTxt = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.MhtBottleTxt = New System.Windows.Forms.TextBox()
        Me.MhtShellTxt = New System.Windows.Forms.TextBox()
        Me.MhtCompTxt = New System.Windows.Forms.TextBox()
        Me.PpCompLbl = New System.Windows.Forms.Label()
        Me.PpShellLbl = New System.Windows.Forms.Label()
        Me.PpBottleLbl = New System.Windows.Forms.Label()
        Me.RhlBottleLbl = New System.Windows.Forms.Label()
        Me.RhlShellLbl = New System.Windows.Forms.Label()
        Me.RhlCompLbl = New System.Windows.Forms.Label()
        Me.RhpBottleLbl = New System.Windows.Forms.Label()
        Me.RhpShellLbl = New System.Windows.Forms.Label()
        Me.RhpCompLbl = New System.Windows.Forms.Label()
        Me.FbaBottleLbl = New System.Windows.Forms.Label()
        Me.FbaShellLbl = New System.Windows.Forms.Label()
        Me.FbaCompLbl = New System.Windows.Forms.Label()
        Me.MhtBottleLbl = New System.Windows.Forms.Label()
        Me.MhtShellLbl = New System.Windows.Forms.Label()
        Me.MhtCompLbl = New System.Windows.Forms.Label()
        Me.TotalSalesLbl = New System.Windows.Forms.Label()
        Me.TotalContRetLbl = New System.Windows.Forms.Label()
        Me.GrossSalesLbl = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.DiscTxt = New System.Windows.Forms.TextBox()
        Me.TolFTxt = New System.Windows.Forms.TextBox()
        Me.PromoTxt = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.AmountRemittedLbl = New System.Windows.Forms.Label()
        Me.CreditAmountTxt1 = New System.Windows.Forms.TextBox()
        Me.CreditAmountTxt2 = New System.Windows.Forms.TextBox()
        Me.CreditAmountTxt3 = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.CollAmountTxt3 = New System.Windows.Forms.TextBox()
        Me.CollAmountTxt2 = New System.Windows.Forms.TextBox()
        Me.CollAmountTxt1 = New System.Windows.Forms.TextBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.ThousandsTxt = New System.Windows.Forms.TextBox()
        Me.FiveHundTxt = New System.Windows.Forms.TextBox()
        Me.OneHundTxt = New System.Windows.Forms.TextBox()
        Me.TwoHundTxt = New System.Windows.Forms.TextBox()
        Me.TwentTxt = New System.Windows.Forms.TextBox()
        Me.FiftyTxt = New System.Windows.Forms.TextBox()
        Me.FiveTxt = New System.Windows.Forms.TextBox()
        Me.TenTxt = New System.Windows.Forms.TextBox()
        Me.CoinsTxt = New System.Windows.Forms.TextBox()
        Me.ThousandsLbl = New System.Windows.Forms.Label()
        Me.FiveHundLbl = New System.Windows.Forms.Label()
        Me.OneHundLbl = New System.Windows.Forms.Label()
        Me.TwoHundLbl = New System.Windows.Forms.Label()
        Me.TenLbl = New System.Windows.Forms.Label()
        Me.TwentLbl = New System.Windows.Forms.Label()
        Me.FiftyLbl = New System.Windows.Forms.Label()
        Me.FiveLbl = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.BankAmountTxt3 = New System.Windows.Forms.TextBox()
        Me.BankAmountTxt2 = New System.Windows.Forms.TextBox()
        Me.BankAmountTxt1 = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.ShortLbl = New System.Windows.Forms.Label()
        Me.OverLbl = New System.Windows.Forms.Label()
        Me.TotalRemitAmountLbl = New System.Windows.Forms.Label()
        Me.SOLbl = New System.Windows.Forms.Label()
        Me.ClearAllTxtBtn = New System.Windows.Forms.Button()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.KrcTxt = New System.Windows.Forms.TextBox()
        Me.PamcLbl = New System.Windows.Forms.Label()
        Me.KrcLbl = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.HscTxt = New System.Windows.Forms.TextBox()
        Me.HscLbl = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.SmlbBottTxt = New System.Windows.Forms.TextBox()
        Me.SmlbBottLbl = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.SmfbTxt = New System.Windows.Forms.TextBox()
        Me.SmfbLbl = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.SmfcTxt = New System.Windows.Forms.TextBox()
        Me.SmfcLbl = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PamcTxt = New System.Windows.Forms.TextBox()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.ReturnSku1Txt = New System.Windows.Forms.TextBox()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.ReturnSku2Txt = New System.Windows.Forms.TextBox()
        Me.ReturnSku3Txt = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(10, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "SALES"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Blue
        Me.Label2.Location = New System.Drawing.Point(10, 35)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "PRODUCT"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Gold
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(98, 35)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "# OF CASES"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Yellow
        Me.Label4.Location = New System.Drawing.Point(196, 35)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "AMOUNT"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(10, 57)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "RH1000"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(10, 80)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "RH500"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(10, 102)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "RH330"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(10, 125)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(51, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "PP1000"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(10, 148)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "PP320"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(10, 171)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "SML330"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(10, 193)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(43, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "FB330"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(10, 216)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(34, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "MHT"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(10, 239)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(86, 13)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "MHT BOTTLE"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(10, 262)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(34, 13)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "CALI"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(10, 284)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(72, 13)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "CNB/PAMB"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(10, 307)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(44, 13)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "FBCan"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Microsoft PhagsPa", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(10, 330)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(90, 15)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "PPC/RHC/SMLC"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(10, 353)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(23, 13)
        Me.Label20.TabIndex = 19
        Me.Label20.Text = "CC"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(10, 375)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(52, 13)
        Me.Label21.TabIndex = 20
        Me.Label21.Text = "GE1000"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(10, 398)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(63, 13)
        Me.Label22.TabIndex = 21
        Me.Label22.Text = "PL BOTT."
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(9, 444)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(81, 13)
        Me.Label23.TabIndex = 22
        Me.Label23.Text = "RHSL BOTT."
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(10, 466)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(71, 13)
        Me.Label24.TabIndex = 23
        Me.Label24.Text = "FBA BOTT."
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(10, 489)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(78, 13)
        Me.Label25.TabIndex = 24
        Me.Label25.Text = "CHOCO LAG"
        '
        'RhlLbl
        '
        Me.RhlLbl.AutoSize = True
        Me.RhlLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhlLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhlLbl.ForeColor = System.Drawing.Color.Black
        Me.RhlLbl.Location = New System.Drawing.Point(202, 57)
        Me.RhlLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhlLbl.Name = "RhlLbl"
        Me.RhlLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhlLbl.TabIndex = 26
        Me.RhlLbl.Text = "00.00"
        '
        'RhlTxt
        '
        Me.RhlTxt.Location = New System.Drawing.Point(98, 54)
        Me.RhlTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhlTxt.Name = "RhlTxt"
        Me.RhlTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhlTxt.TabIndex = 48
        '
        'RhpTxt
        '
        Me.RhpTxt.Location = New System.Drawing.Point(98, 77)
        Me.RhpTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhpTxt.Name = "RhpTxt"
        Me.RhpTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhpTxt.TabIndex = 49
        '
        'RhpLbl
        '
        Me.RhpLbl.AutoSize = True
        Me.RhpLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhpLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhpLbl.ForeColor = System.Drawing.Color.Black
        Me.RhpLbl.Location = New System.Drawing.Point(202, 80)
        Me.RhpLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhpLbl.Name = "RhpLbl"
        Me.RhpLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhpLbl.TabIndex = 70
        Me.RhpLbl.Text = "00.00"
        '
        'PlTxt
        '
        Me.PlTxt.Location = New System.Drawing.Point(98, 123)
        Me.PlTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.PlTxt.Name = "PlTxt"
        Me.PlTxt.Size = New System.Drawing.Size(76, 20)
        Me.PlTxt.TabIndex = 72
        '
        'RhsTxt
        '
        Me.RhsTxt.Location = New System.Drawing.Point(98, 100)
        Me.RhsTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhsTxt.Name = "RhsTxt"
        Me.RhsTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhsTxt.TabIndex = 71
        '
        'SmlbTxt
        '
        Me.SmlbTxt.Location = New System.Drawing.Point(98, 168)
        Me.SmlbTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.SmlbTxt.Name = "SmlbTxt"
        Me.SmlbTxt.Size = New System.Drawing.Size(76, 20)
        Me.SmlbTxt.TabIndex = 74
        '
        'Pp320Txt
        '
        Me.Pp320Txt.Location = New System.Drawing.Point(98, 145)
        Me.Pp320Txt.Margin = New System.Windows.Forms.Padding(2)
        Me.Pp320Txt.Name = "Pp320Txt"
        Me.Pp320Txt.Size = New System.Drawing.Size(76, 20)
        Me.Pp320Txt.TabIndex = 73
        '
        'MhtTxt
        '
        Me.MhtTxt.Location = New System.Drawing.Point(98, 214)
        Me.MhtTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.MhtTxt.Name = "MhtTxt"
        Me.MhtTxt.Size = New System.Drawing.Size(76, 20)
        Me.MhtTxt.TabIndex = 76
        '
        'FbTxt
        '
        Me.FbTxt.Location = New System.Drawing.Point(98, 191)
        Me.FbTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FbTxt.Name = "FbTxt"
        Me.FbTxt.Size = New System.Drawing.Size(76, 20)
        Me.FbTxt.TabIndex = 75
        '
        'CbTxt
        '
        Me.CbTxt.Location = New System.Drawing.Point(98, 259)
        Me.CbTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.CbTxt.Name = "CbTxt"
        Me.CbTxt.Size = New System.Drawing.Size(76, 20)
        Me.CbTxt.TabIndex = 78
        '
        'MhtBottTxt
        '
        Me.MhtBottTxt.Location = New System.Drawing.Point(98, 236)
        Me.MhtBottTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.MhtBottTxt.Name = "MhtBottTxt"
        Me.MhtBottTxt.Size = New System.Drawing.Size(76, 20)
        Me.MhtBottTxt.TabIndex = 77
        '
        'FbcTxt
        '
        Me.FbcTxt.Location = New System.Drawing.Point(98, 305)
        Me.FbcTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FbcTxt.Name = "FbcTxt"
        Me.FbcTxt.Size = New System.Drawing.Size(76, 20)
        Me.FbcTxt.TabIndex = 80
        '
        'CnbTxt
        '
        Me.CnbTxt.Location = New System.Drawing.Point(98, 282)
        Me.CnbTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.CnbTxt.Name = "CnbTxt"
        Me.CnbTxt.Size = New System.Drawing.Size(76, 20)
        Me.CnbTxt.TabIndex = 79
        '
        'CcTxt
        '
        Me.CcTxt.Location = New System.Drawing.Point(98, 350)
        Me.CcTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.CcTxt.Name = "CcTxt"
        Me.CcTxt.Size = New System.Drawing.Size(76, 20)
        Me.CcTxt.TabIndex = 82
        '
        'PpcTxt
        '
        Me.PpcTxt.Location = New System.Drawing.Point(98, 327)
        Me.PpcTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.PpcTxt.Name = "PpcTxt"
        Me.PpcTxt.Size = New System.Drawing.Size(76, 20)
        Me.PpcTxt.TabIndex = 81
        '
        'GekTxt
        '
        Me.GekTxt.Location = New System.Drawing.Point(98, 373)
        Me.GekTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.GekTxt.Name = "GekTxt"
        Me.GekTxt.Size = New System.Drawing.Size(76, 20)
        Me.GekTxt.TabIndex = 83
        '
        'PlLbl
        '
        Me.PlLbl.AutoSize = True
        Me.PlLbl.BackColor = System.Drawing.Color.Transparent
        Me.PlLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlLbl.ForeColor = System.Drawing.Color.Black
        Me.PlLbl.Location = New System.Drawing.Point(202, 125)
        Me.PlLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PlLbl.Name = "PlLbl"
        Me.PlLbl.Size = New System.Drawing.Size(39, 13)
        Me.PlLbl.TabIndex = 89
        Me.PlLbl.Text = "00.00"
        '
        'RhsLbl
        '
        Me.RhsLbl.AutoSize = True
        Me.RhsLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhsLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhsLbl.ForeColor = System.Drawing.Color.Black
        Me.RhsLbl.Location = New System.Drawing.Point(202, 102)
        Me.RhsLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhsLbl.Name = "RhsLbl"
        Me.RhsLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhsLbl.TabIndex = 88
        Me.RhsLbl.Text = "00.00"
        '
        'SmlbLbl
        '
        Me.SmlbLbl.AutoSize = True
        Me.SmlbLbl.BackColor = System.Drawing.Color.Transparent
        Me.SmlbLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SmlbLbl.ForeColor = System.Drawing.Color.Black
        Me.SmlbLbl.Location = New System.Drawing.Point(202, 171)
        Me.SmlbLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.SmlbLbl.Name = "SmlbLbl"
        Me.SmlbLbl.Size = New System.Drawing.Size(39, 13)
        Me.SmlbLbl.TabIndex = 91
        Me.SmlbLbl.Text = "00.00"
        '
        'Pp320Lbl
        '
        Me.Pp320Lbl.AutoSize = True
        Me.Pp320Lbl.BackColor = System.Drawing.Color.Transparent
        Me.Pp320Lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pp320Lbl.ForeColor = System.Drawing.Color.Black
        Me.Pp320Lbl.Location = New System.Drawing.Point(202, 148)
        Me.Pp320Lbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Pp320Lbl.Name = "Pp320Lbl"
        Me.Pp320Lbl.Size = New System.Drawing.Size(39, 13)
        Me.Pp320Lbl.TabIndex = 90
        Me.Pp320Lbl.Text = "00.00"
        '
        'MhtLbl
        '
        Me.MhtLbl.AutoSize = True
        Me.MhtLbl.BackColor = System.Drawing.Color.Transparent
        Me.MhtLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MhtLbl.ForeColor = System.Drawing.Color.Black
        Me.MhtLbl.Location = New System.Drawing.Point(202, 216)
        Me.MhtLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.MhtLbl.Name = "MhtLbl"
        Me.MhtLbl.Size = New System.Drawing.Size(39, 13)
        Me.MhtLbl.TabIndex = 93
        Me.MhtLbl.Text = "00.00"
        '
        'FbLbl
        '
        Me.FbLbl.AutoSize = True
        Me.FbLbl.BackColor = System.Drawing.Color.Transparent
        Me.FbLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FbLbl.ForeColor = System.Drawing.Color.Black
        Me.FbLbl.Location = New System.Drawing.Point(202, 193)
        Me.FbLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FbLbl.Name = "FbLbl"
        Me.FbLbl.Size = New System.Drawing.Size(39, 13)
        Me.FbLbl.TabIndex = 92
        Me.FbLbl.Text = "00.00"
        '
        'CbLbl
        '
        Me.CbLbl.AutoSize = True
        Me.CbLbl.BackColor = System.Drawing.Color.Transparent
        Me.CbLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbLbl.ForeColor = System.Drawing.Color.Black
        Me.CbLbl.Location = New System.Drawing.Point(202, 262)
        Me.CbLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.CbLbl.Name = "CbLbl"
        Me.CbLbl.Size = New System.Drawing.Size(39, 13)
        Me.CbLbl.TabIndex = 95
        Me.CbLbl.Text = "00.00"
        '
        'MhtBottLbl
        '
        Me.MhtBottLbl.AutoSize = True
        Me.MhtBottLbl.BackColor = System.Drawing.Color.Transparent
        Me.MhtBottLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MhtBottLbl.ForeColor = System.Drawing.Color.Black
        Me.MhtBottLbl.Location = New System.Drawing.Point(202, 239)
        Me.MhtBottLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.MhtBottLbl.Name = "MhtBottLbl"
        Me.MhtBottLbl.Size = New System.Drawing.Size(39, 13)
        Me.MhtBottLbl.TabIndex = 94
        Me.MhtBottLbl.Text = "00.00"
        '
        'FbcLbl
        '
        Me.FbcLbl.AutoSize = True
        Me.FbcLbl.BackColor = System.Drawing.Color.Transparent
        Me.FbcLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FbcLbl.ForeColor = System.Drawing.Color.Black
        Me.FbcLbl.Location = New System.Drawing.Point(202, 307)
        Me.FbcLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FbcLbl.Name = "FbcLbl"
        Me.FbcLbl.Size = New System.Drawing.Size(39, 13)
        Me.FbcLbl.TabIndex = 97
        Me.FbcLbl.Text = "00.00"
        '
        'CnbLbl
        '
        Me.CnbLbl.AutoSize = True
        Me.CnbLbl.BackColor = System.Drawing.Color.Transparent
        Me.CnbLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CnbLbl.ForeColor = System.Drawing.Color.Black
        Me.CnbLbl.Location = New System.Drawing.Point(202, 284)
        Me.CnbLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.CnbLbl.Name = "CnbLbl"
        Me.CnbLbl.Size = New System.Drawing.Size(39, 13)
        Me.CnbLbl.TabIndex = 96
        Me.CnbLbl.Text = "00.00"
        '
        'CcLbl
        '
        Me.CcLbl.AutoSize = True
        Me.CcLbl.BackColor = System.Drawing.Color.Transparent
        Me.CcLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CcLbl.ForeColor = System.Drawing.Color.Black
        Me.CcLbl.Location = New System.Drawing.Point(202, 353)
        Me.CcLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.CcLbl.Name = "CcLbl"
        Me.CcLbl.Size = New System.Drawing.Size(39, 13)
        Me.CcLbl.TabIndex = 99
        Me.CcLbl.Text = "00.00"
        '
        'PpcLbl
        '
        Me.PpcLbl.AutoSize = True
        Me.PpcLbl.BackColor = System.Drawing.Color.Transparent
        Me.PpcLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PpcLbl.ForeColor = System.Drawing.Color.Black
        Me.PpcLbl.Location = New System.Drawing.Point(202, 330)
        Me.PpcLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PpcLbl.Name = "PpcLbl"
        Me.PpcLbl.Size = New System.Drawing.Size(39, 13)
        Me.PpcLbl.TabIndex = 98
        Me.PpcLbl.Text = "00.00"
        '
        'GekLbl
        '
        Me.GekLbl.AutoSize = True
        Me.GekLbl.BackColor = System.Drawing.Color.Transparent
        Me.GekLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GekLbl.ForeColor = System.Drawing.Color.Black
        Me.GekLbl.Location = New System.Drawing.Point(202, 375)
        Me.GekLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.GekLbl.Name = "GekLbl"
        Me.GekLbl.Size = New System.Drawing.Size(39, 13)
        Me.GekLbl.TabIndex = 100
        Me.GekLbl.Text = "00.00"
        '
        'RhslTxt
        '
        Me.RhslTxt.Location = New System.Drawing.Point(98, 418)
        Me.RhslTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhslTxt.Name = "RhslTxt"
        Me.RhslTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhslTxt.TabIndex = 113
        '
        'PlBottTxt
        '
        Me.PlBottTxt.Location = New System.Drawing.Point(98, 396)
        Me.PlBottTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.PlBottTxt.Name = "PlBottTxt"
        Me.PlBottTxt.Size = New System.Drawing.Size(76, 20)
        Me.PlBottTxt.TabIndex = 112
        '
        'FbBottTxt
        '
        Me.FbBottTxt.Location = New System.Drawing.Point(98, 464)
        Me.FbBottTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FbBottTxt.Name = "FbBottTxt"
        Me.FbBottTxt.Size = New System.Drawing.Size(76, 20)
        Me.FbBottTxt.TabIndex = 115
        '
        'RhslBottTxt
        '
        Me.RhslBottTxt.Location = New System.Drawing.Point(98, 441)
        Me.RhslBottTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhslBottTxt.Name = "RhslBottTxt"
        Me.RhslBottTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhslBottTxt.TabIndex = 114
        '
        'ChocLagTxt
        '
        Me.ChocLagTxt.Location = New System.Drawing.Point(98, 487)
        Me.ChocLagTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.ChocLagTxt.Name = "ChocLagTxt"
        Me.ChocLagTxt.Size = New System.Drawing.Size(76, 20)
        Me.ChocLagTxt.TabIndex = 118
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(10, 421)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(40, 13)
        Me.Label16.TabIndex = 119
        Me.Label16.Text = "RHSL"
        '
        'RhslLbl
        '
        Me.RhslLbl.AutoSize = True
        Me.RhslLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhslLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhslLbl.ForeColor = System.Drawing.Color.Black
        Me.RhslLbl.Location = New System.Drawing.Point(202, 421)
        Me.RhslLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhslLbl.Name = "RhslLbl"
        Me.RhslLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhslLbl.TabIndex = 121
        Me.RhslLbl.Text = "00.00"
        '
        'PlBottLbl
        '
        Me.PlBottLbl.AutoSize = True
        Me.PlBottLbl.BackColor = System.Drawing.Color.Transparent
        Me.PlBottLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlBottLbl.ForeColor = System.Drawing.Color.Black
        Me.PlBottLbl.Location = New System.Drawing.Point(202, 398)
        Me.PlBottLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PlBottLbl.Name = "PlBottLbl"
        Me.PlBottLbl.Size = New System.Drawing.Size(39, 13)
        Me.PlBottLbl.TabIndex = 120
        Me.PlBottLbl.Text = "00.00"
        '
        'FbBottLbl
        '
        Me.FbBottLbl.AutoSize = True
        Me.FbBottLbl.BackColor = System.Drawing.Color.Transparent
        Me.FbBottLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FbBottLbl.ForeColor = System.Drawing.Color.Black
        Me.FbBottLbl.Location = New System.Drawing.Point(202, 466)
        Me.FbBottLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FbBottLbl.Name = "FbBottLbl"
        Me.FbBottLbl.Size = New System.Drawing.Size(39, 13)
        Me.FbBottLbl.TabIndex = 123
        Me.FbBottLbl.Text = "00.00"
        '
        'RhslBottLbl
        '
        Me.RhslBottLbl.AutoSize = True
        Me.RhslBottLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhslBottLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhslBottLbl.ForeColor = System.Drawing.Color.Black
        Me.RhslBottLbl.Location = New System.Drawing.Point(202, 444)
        Me.RhslBottLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhslBottLbl.Name = "RhslBottLbl"
        Me.RhslBottLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhslBottLbl.TabIndex = 122
        Me.RhslBottLbl.Text = "00.00"
        '
        'ChocLagLbl
        '
        Me.ChocLagLbl.AutoSize = True
        Me.ChocLagLbl.BackColor = System.Drawing.Color.Transparent
        Me.ChocLagLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChocLagLbl.ForeColor = System.Drawing.Color.Black
        Me.ChocLagLbl.Location = New System.Drawing.Point(202, 489)
        Me.ChocLagLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ChocLagLbl.Name = "ChocLagLbl"
        Me.ChocLagLbl.Size = New System.Drawing.Size(39, 13)
        Me.ChocLagLbl.TabIndex = 124
        Me.ChocLagLbl.Text = "00.00"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(288, 11)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(197, 17)
        Me.Label17.TabIndex = 127
        Me.Label17.Text = "CONTAINERS RETURNED" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Yellow
        Me.Label26.Location = New System.Drawing.Point(461, 35)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(60, 13)
        Me.Label26.TabIndex = 130
        Me.Label26.Text = "AMOUNT"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Gold
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(399, 35)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(32, 13)
        Me.Label27.TabIndex = 129
        Me.Label27.Text = "QTY"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Blue
        Me.Label28.Location = New System.Drawing.Point(304, 35)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(67, 13)
        Me.Label28.TabIndex = 128
        Me.Label28.Text = "PRODUCT"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Blue
        Me.Label29.Location = New System.Drawing.Point(279, 54)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(23, 13)
        Me.Label29.TabIndex = 131
        Me.Label29.Text = "PP"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(304, 58)
        Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 13)
        Me.Label30.TabIndex = 132
        Me.Label30.Text = "COMPLETE"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(304, 80)
        Me.Label31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(46, 13)
        Me.Label31.TabIndex = 133
        Me.Label31.Text = "SHELL"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(304, 100)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(55, 13)
        Me.Label32.TabIndex = 134
        Me.Label32.Text = "BOTTLE"
        '
        'PpCompTxt
        '
        Me.PpCompTxt.Location = New System.Drawing.Point(377, 54)
        Me.PpCompTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.PpCompTxt.Name = "PpCompTxt"
        Me.PpCompTxt.Size = New System.Drawing.Size(76, 20)
        Me.PpCompTxt.TabIndex = 135
        '
        'PpShellTxt
        '
        Me.PpShellTxt.Location = New System.Drawing.Point(377, 77)
        Me.PpShellTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.PpShellTxt.Name = "PpShellTxt"
        Me.PpShellTxt.Size = New System.Drawing.Size(76, 20)
        Me.PpShellTxt.TabIndex = 136
        '
        'PpBottleTxt
        '
        Me.PpBottleTxt.Location = New System.Drawing.Point(377, 100)
        Me.PpBottleTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.PpBottleTxt.Name = "PpBottleTxt"
        Me.PpBottleTxt.Size = New System.Drawing.Size(76, 20)
        Me.PpBottleTxt.TabIndex = 137
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Blue
        Me.Label33.Location = New System.Drawing.Point(279, 127)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(84, 13)
        Me.Label33.TabIndex = 138
        Me.Label33.Text = "RHL/PL/GEK"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(304, 191)
        Me.Label34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(55, 13)
        Me.Label34.TabIndex = 141
        Me.Label34.Text = "BOTTLE"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(304, 171)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(46, 13)
        Me.Label35.TabIndex = 140
        Me.Label35.Text = "SHELL"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(304, 150)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(73, 13)
        Me.Label36.TabIndex = 139
        Me.Label36.Text = "COMPLETE"
        '
        'RhlBottleTxt
        '
        Me.RhlBottleTxt.Location = New System.Drawing.Point(377, 191)
        Me.RhlBottleTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhlBottleTxt.Name = "RhlBottleTxt"
        Me.RhlBottleTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhlBottleTxt.TabIndex = 144
        '
        'RhlShellTxt
        '
        Me.RhlShellTxt.Location = New System.Drawing.Point(377, 168)
        Me.RhlShellTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhlShellTxt.Name = "RhlShellTxt"
        Me.RhlShellTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhlShellTxt.TabIndex = 143
        '
        'RhlCompTxt
        '
        Me.RhlCompTxt.Location = New System.Drawing.Point(377, 145)
        Me.RhlCompTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhlCompTxt.Name = "RhlCompTxt"
        Me.RhlCompTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhlCompTxt.TabIndex = 142
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Blue
        Me.Label37.Location = New System.Drawing.Point(279, 218)
        Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(33, 13)
        Me.Label37.TabIndex = 145
        Me.Label37.Text = "RHP"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.Color.Transparent
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(304, 278)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(55, 13)
        Me.Label38.TabIndex = 148
        Me.Label38.Text = "BOTTLE"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.BackColor = System.Drawing.Color.Transparent
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(304, 258)
        Me.Label39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(46, 13)
        Me.Label39.TabIndex = 147
        Me.Label39.Text = "SHELL"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.BackColor = System.Drawing.Color.Transparent
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(304, 236)
        Me.Label40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(73, 13)
        Me.Label40.TabIndex = 146
        Me.Label40.Text = "COMPLETE"
        '
        'RhpBottleTxt
        '
        Me.RhpBottleTxt.Location = New System.Drawing.Point(377, 282)
        Me.RhpBottleTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhpBottleTxt.Name = "RhpBottleTxt"
        Me.RhpBottleTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhpBottleTxt.TabIndex = 151
        '
        'RhpShellTxt
        '
        Me.RhpShellTxt.Location = New System.Drawing.Point(377, 259)
        Me.RhpShellTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhpShellTxt.Name = "RhpShellTxt"
        Me.RhpShellTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhpShellTxt.TabIndex = 150
        '
        'RhpCompTxt
        '
        Me.RhpCompTxt.Location = New System.Drawing.Point(377, 236)
        Me.RhpCompTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.RhpCompTxt.Name = "RhpCompTxt"
        Me.RhpCompTxt.Size = New System.Drawing.Size(76, 20)
        Me.RhpCompTxt.TabIndex = 149
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.BackColor = System.Drawing.Color.Transparent
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Blue
        Me.Label41.Location = New System.Drawing.Point(279, 309)
        Me.Label41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(93, 13)
        Me.Label41.TabIndex = 152
        Me.Label41.Text = "FBA/SML/RHS"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.Transparent
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(304, 371)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(55, 13)
        Me.Label42.TabIndex = 155
        Me.Label42.Text = "BOTTLE"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.BackColor = System.Drawing.Color.Transparent
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(304, 351)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(46, 13)
        Me.Label43.TabIndex = 154
        Me.Label43.Text = "SHELL"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.BackColor = System.Drawing.Color.Transparent
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(304, 330)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(73, 13)
        Me.Label44.TabIndex = 153
        Me.Label44.Text = "COMPLETE"
        '
        'FbaBottleTxt
        '
        Me.FbaBottleTxt.Location = New System.Drawing.Point(377, 373)
        Me.FbaBottleTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FbaBottleTxt.Name = "FbaBottleTxt"
        Me.FbaBottleTxt.Size = New System.Drawing.Size(76, 20)
        Me.FbaBottleTxt.TabIndex = 158
        '
        'FbaShellTxt
        '
        Me.FbaShellTxt.Location = New System.Drawing.Point(377, 350)
        Me.FbaShellTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FbaShellTxt.Name = "FbaShellTxt"
        Me.FbaShellTxt.Size = New System.Drawing.Size(76, 20)
        Me.FbaShellTxt.TabIndex = 157
        '
        'FbaCompTxt
        '
        Me.FbaCompTxt.Location = New System.Drawing.Point(377, 327)
        Me.FbaCompTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FbaCompTxt.Name = "FbaCompTxt"
        Me.FbaCompTxt.Size = New System.Drawing.Size(76, 20)
        Me.FbaCompTxt.TabIndex = 156
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.BackColor = System.Drawing.Color.Transparent
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Blue
        Me.Label45.Location = New System.Drawing.Point(279, 400)
        Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(34, 13)
        Me.Label45.TabIndex = 159
        Me.Label45.Text = "MHT"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.BackColor = System.Drawing.Color.Transparent
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(304, 464)
        Me.Label46.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(55, 13)
        Me.Label46.TabIndex = 162
        Me.Label46.Text = "BOTTLE"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.BackColor = System.Drawing.Color.Transparent
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(304, 444)
        Me.Label47.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(46, 13)
        Me.Label47.TabIndex = 161
        Me.Label47.Text = "SHELL"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.BackColor = System.Drawing.Color.Transparent
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(304, 422)
        Me.Label48.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(73, 13)
        Me.Label48.TabIndex = 160
        Me.Label48.Text = "COMPLETE"
        '
        'MhtBottleTxt
        '
        Me.MhtBottleTxt.Location = New System.Drawing.Point(377, 466)
        Me.MhtBottleTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.MhtBottleTxt.Name = "MhtBottleTxt"
        Me.MhtBottleTxt.Size = New System.Drawing.Size(76, 20)
        Me.MhtBottleTxt.TabIndex = 165
        '
        'MhtShellTxt
        '
        Me.MhtShellTxt.Location = New System.Drawing.Point(377, 443)
        Me.MhtShellTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.MhtShellTxt.Name = "MhtShellTxt"
        Me.MhtShellTxt.Size = New System.Drawing.Size(76, 20)
        Me.MhtShellTxt.TabIndex = 164
        '
        'MhtCompTxt
        '
        Me.MhtCompTxt.Location = New System.Drawing.Point(377, 420)
        Me.MhtCompTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.MhtCompTxt.Name = "MhtCompTxt"
        Me.MhtCompTxt.Size = New System.Drawing.Size(76, 20)
        Me.MhtCompTxt.TabIndex = 163
        '
        'PpCompLbl
        '
        Me.PpCompLbl.AutoSize = True
        Me.PpCompLbl.BackColor = System.Drawing.Color.Transparent
        Me.PpCompLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PpCompLbl.Location = New System.Drawing.Point(468, 57)
        Me.PpCompLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PpCompLbl.Name = "PpCompLbl"
        Me.PpCompLbl.Size = New System.Drawing.Size(39, 13)
        Me.PpCompLbl.TabIndex = 166
        Me.PpCompLbl.Text = "00.00"
        '
        'PpShellLbl
        '
        Me.PpShellLbl.AutoSize = True
        Me.PpShellLbl.BackColor = System.Drawing.Color.Transparent
        Me.PpShellLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PpShellLbl.Location = New System.Drawing.Point(468, 80)
        Me.PpShellLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PpShellLbl.Name = "PpShellLbl"
        Me.PpShellLbl.Size = New System.Drawing.Size(39, 13)
        Me.PpShellLbl.TabIndex = 167
        Me.PpShellLbl.Text = "00.00"
        '
        'PpBottleLbl
        '
        Me.PpBottleLbl.AutoSize = True
        Me.PpBottleLbl.BackColor = System.Drawing.Color.Transparent
        Me.PpBottleLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PpBottleLbl.Location = New System.Drawing.Point(468, 102)
        Me.PpBottleLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PpBottleLbl.Name = "PpBottleLbl"
        Me.PpBottleLbl.Size = New System.Drawing.Size(39, 13)
        Me.PpBottleLbl.TabIndex = 168
        Me.PpBottleLbl.Text = "00.00"
        '
        'RhlBottleLbl
        '
        Me.RhlBottleLbl.AutoSize = True
        Me.RhlBottleLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhlBottleLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhlBottleLbl.Location = New System.Drawing.Point(468, 193)
        Me.RhlBottleLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhlBottleLbl.Name = "RhlBottleLbl"
        Me.RhlBottleLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhlBottleLbl.TabIndex = 171
        Me.RhlBottleLbl.Text = "00.00"
        '
        'RhlShellLbl
        '
        Me.RhlShellLbl.AutoSize = True
        Me.RhlShellLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhlShellLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhlShellLbl.Location = New System.Drawing.Point(468, 171)
        Me.RhlShellLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhlShellLbl.Name = "RhlShellLbl"
        Me.RhlShellLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhlShellLbl.TabIndex = 170
        Me.RhlShellLbl.Text = "00.00"
        '
        'RhlCompLbl
        '
        Me.RhlCompLbl.AutoSize = True
        Me.RhlCompLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhlCompLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhlCompLbl.Location = New System.Drawing.Point(468, 148)
        Me.RhlCompLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhlCompLbl.Name = "RhlCompLbl"
        Me.RhlCompLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhlCompLbl.TabIndex = 169
        Me.RhlCompLbl.Text = "00.00"
        '
        'RhpBottleLbl
        '
        Me.RhpBottleLbl.AutoSize = True
        Me.RhpBottleLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhpBottleLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhpBottleLbl.Location = New System.Drawing.Point(468, 284)
        Me.RhpBottleLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhpBottleLbl.Name = "RhpBottleLbl"
        Me.RhpBottleLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhpBottleLbl.TabIndex = 174
        Me.RhpBottleLbl.Text = "00.00"
        '
        'RhpShellLbl
        '
        Me.RhpShellLbl.AutoSize = True
        Me.RhpShellLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhpShellLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhpShellLbl.Location = New System.Drawing.Point(468, 262)
        Me.RhpShellLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhpShellLbl.Name = "RhpShellLbl"
        Me.RhpShellLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhpShellLbl.TabIndex = 173
        Me.RhpShellLbl.Text = "00.00"
        '
        'RhpCompLbl
        '
        Me.RhpCompLbl.AutoSize = True
        Me.RhpCompLbl.BackColor = System.Drawing.Color.Transparent
        Me.RhpCompLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RhpCompLbl.Location = New System.Drawing.Point(468, 239)
        Me.RhpCompLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.RhpCompLbl.Name = "RhpCompLbl"
        Me.RhpCompLbl.Size = New System.Drawing.Size(39, 13)
        Me.RhpCompLbl.TabIndex = 172
        Me.RhpCompLbl.Text = "00.00"
        '
        'FbaBottleLbl
        '
        Me.FbaBottleLbl.AutoSize = True
        Me.FbaBottleLbl.BackColor = System.Drawing.Color.Transparent
        Me.FbaBottleLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FbaBottleLbl.Location = New System.Drawing.Point(468, 375)
        Me.FbaBottleLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FbaBottleLbl.Name = "FbaBottleLbl"
        Me.FbaBottleLbl.Size = New System.Drawing.Size(39, 13)
        Me.FbaBottleLbl.TabIndex = 177
        Me.FbaBottleLbl.Text = "00.00"
        '
        'FbaShellLbl
        '
        Me.FbaShellLbl.AutoSize = True
        Me.FbaShellLbl.BackColor = System.Drawing.Color.Transparent
        Me.FbaShellLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FbaShellLbl.Location = New System.Drawing.Point(468, 353)
        Me.FbaShellLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FbaShellLbl.Name = "FbaShellLbl"
        Me.FbaShellLbl.Size = New System.Drawing.Size(39, 13)
        Me.FbaShellLbl.TabIndex = 176
        Me.FbaShellLbl.Text = "00.00"
        '
        'FbaCompLbl
        '
        Me.FbaCompLbl.AutoSize = True
        Me.FbaCompLbl.BackColor = System.Drawing.Color.Transparent
        Me.FbaCompLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FbaCompLbl.Location = New System.Drawing.Point(468, 330)
        Me.FbaCompLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FbaCompLbl.Name = "FbaCompLbl"
        Me.FbaCompLbl.Size = New System.Drawing.Size(39, 13)
        Me.FbaCompLbl.TabIndex = 175
        Me.FbaCompLbl.Text = "00.00"
        '
        'MhtBottleLbl
        '
        Me.MhtBottleLbl.AutoSize = True
        Me.MhtBottleLbl.BackColor = System.Drawing.Color.Transparent
        Me.MhtBottleLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MhtBottleLbl.Location = New System.Drawing.Point(468, 468)
        Me.MhtBottleLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.MhtBottleLbl.Name = "MhtBottleLbl"
        Me.MhtBottleLbl.Size = New System.Drawing.Size(39, 13)
        Me.MhtBottleLbl.TabIndex = 180
        Me.MhtBottleLbl.Text = "00.00"
        '
        'MhtShellLbl
        '
        Me.MhtShellLbl.AutoSize = True
        Me.MhtShellLbl.BackColor = System.Drawing.Color.Transparent
        Me.MhtShellLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MhtShellLbl.Location = New System.Drawing.Point(468, 445)
        Me.MhtShellLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.MhtShellLbl.Name = "MhtShellLbl"
        Me.MhtShellLbl.Size = New System.Drawing.Size(39, 13)
        Me.MhtShellLbl.TabIndex = 179
        Me.MhtShellLbl.Text = "00.00"
        '
        'MhtCompLbl
        '
        Me.MhtCompLbl.AutoSize = True
        Me.MhtCompLbl.BackColor = System.Drawing.Color.Transparent
        Me.MhtCompLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MhtCompLbl.Location = New System.Drawing.Point(468, 422)
        Me.MhtCompLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.MhtCompLbl.Name = "MhtCompLbl"
        Me.MhtCompLbl.Size = New System.Drawing.Size(39, 13)
        Me.MhtCompLbl.TabIndex = 178
        Me.MhtCompLbl.Text = "00.00"
        '
        'TotalSalesLbl
        '
        Me.TotalSalesLbl.AutoSize = True
        Me.TotalSalesLbl.BackColor = System.Drawing.Color.Transparent
        Me.TotalSalesLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalSalesLbl.ForeColor = System.Drawing.Color.Gold
        Me.TotalSalesLbl.Location = New System.Drawing.Point(9, 687)
        Me.TotalSalesLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.TotalSalesLbl.Name = "TotalSalesLbl"
        Me.TotalSalesLbl.Size = New System.Drawing.Size(192, 15)
        Me.TotalSalesLbl.TabIndex = 182
        Me.TotalSalesLbl.Text = "CLICK TO SEE TOTAL SALES"
        '
        'TotalContRetLbl
        '
        Me.TotalContRetLbl.AutoSize = True
        Me.TotalContRetLbl.BackColor = System.Drawing.Color.Transparent
        Me.TotalContRetLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalContRetLbl.ForeColor = System.Drawing.Color.Red
        Me.TotalContRetLbl.Location = New System.Drawing.Point(280, 500)
        Me.TotalContRetLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.TotalContRetLbl.Name = "TotalContRetLbl"
        Me.TotalContRetLbl.Size = New System.Drawing.Size(363, 17)
        Me.TotalContRetLbl.TabIndex = 183
        Me.TotalContRetLbl.Text = "CLICK TO SEE TOTAL CONTAINERS RETURNED"
        '
        'GrossSalesLbl
        '
        Me.GrossSalesLbl.AutoSize = True
        Me.GrossSalesLbl.BackColor = System.Drawing.Color.Transparent
        Me.GrossSalesLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrossSalesLbl.ForeColor = System.Drawing.Color.Yellow
        Me.GrossSalesLbl.Location = New System.Drawing.Point(280, 526)
        Me.GrossSalesLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.GrossSalesLbl.Name = "GrossSalesLbl"
        Me.GrossSalesLbl.Size = New System.Drawing.Size(283, 17)
        Me.GrossSalesLbl.TabIndex = 184
        Me.GrossSalesLbl.Text = "CLICK TO SEE TOTAL GROSS SALES"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.BackColor = System.Drawing.Color.Transparent
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Red
        Me.Label49.Location = New System.Drawing.Point(571, 54)
        Me.Label49.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(75, 13)
        Me.Label49.TabIndex = 186
        Me.Label49.Text = "DISCOUNT:"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.BackColor = System.Drawing.Color.Transparent
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Red
        Me.Label50.Location = New System.Drawing.Point(575, 80)
        Me.Label50.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(69, 13)
        Me.Label50.TabIndex = 187
        Me.Label50.Text = "TOLL FEE:"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.BackColor = System.Drawing.Color.Transparent
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.Red
        Me.Label51.Location = New System.Drawing.Point(588, 108)
        Me.Label51.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(56, 13)
        Me.Label51.TabIndex = 188
        Me.Label51.Text = "PROMO:"
        '
        'DiscTxt
        '
        Me.DiscTxt.Location = New System.Drawing.Point(645, 51)
        Me.DiscTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.DiscTxt.Name = "DiscTxt"
        Me.DiscTxt.Size = New System.Drawing.Size(76, 20)
        Me.DiscTxt.TabIndex = 189
        '
        'TolFTxt
        '
        Me.TolFTxt.Location = New System.Drawing.Point(645, 77)
        Me.TolFTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.TolFTxt.Name = "TolFTxt"
        Me.TolFTxt.Size = New System.Drawing.Size(76, 20)
        Me.TolFTxt.TabIndex = 190
        '
        'PromoTxt
        '
        Me.PromoTxt.Location = New System.Drawing.Point(645, 103)
        Me.PromoTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.PromoTxt.Name = "PromoTxt"
        Me.PromoTxt.Size = New System.Drawing.Size(76, 20)
        Me.PromoTxt.TabIndex = 191
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.BackColor = System.Drawing.Color.Transparent
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Red
        Me.Label52.Location = New System.Drawing.Point(571, 147)
        Me.Label52.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(92, 13)
        Me.Label52.TabIndex = 192
        Me.Label52.Text = "LESS: CREDIT"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.BackColor = System.Drawing.Color.Transparent
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.Red
        Me.Label53.Location = New System.Drawing.Point(581, 173)
        Me.Label53.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(64, 13)
        Me.Label53.TabIndex = 193
        Me.Label53.Text = "AMOUNT:"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.BackColor = System.Drawing.Color.Transparent
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(571, 340)
        Me.Label54.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(173, 13)
        Me.Label54.TabIndex = 194
        Me.Label54.Text = "AMOUNT TO BE REMITTED:"
        '
        'AmountRemittedLbl
        '
        Me.AmountRemittedLbl.AutoSize = True
        Me.AmountRemittedLbl.BackColor = System.Drawing.Color.Transparent
        Me.AmountRemittedLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AmountRemittedLbl.ForeColor = System.Drawing.Color.Gold
        Me.AmountRemittedLbl.Location = New System.Drawing.Point(571, 368)
        Me.AmountRemittedLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.AmountRemittedLbl.Name = "AmountRemittedLbl"
        Me.AmountRemittedLbl.Size = New System.Drawing.Size(151, 17)
        Me.AmountRemittedLbl.TabIndex = 195
        Me.AmountRemittedLbl.Text = "Click to see Amount"
        '
        'CreditAmountTxt1
        '
        Me.CreditAmountTxt1.Location = New System.Drawing.Point(645, 171)
        Me.CreditAmountTxt1.Margin = New System.Windows.Forms.Padding(2)
        Me.CreditAmountTxt1.Name = "CreditAmountTxt1"
        Me.CreditAmountTxt1.Size = New System.Drawing.Size(76, 20)
        Me.CreditAmountTxt1.TabIndex = 196
        '
        'CreditAmountTxt2
        '
        Me.CreditAmountTxt2.Location = New System.Drawing.Point(645, 194)
        Me.CreditAmountTxt2.Margin = New System.Windows.Forms.Padding(2)
        Me.CreditAmountTxt2.Name = "CreditAmountTxt2"
        Me.CreditAmountTxt2.Size = New System.Drawing.Size(76, 20)
        Me.CreditAmountTxt2.TabIndex = 197
        '
        'CreditAmountTxt3
        '
        Me.CreditAmountTxt3.Location = New System.Drawing.Point(645, 216)
        Me.CreditAmountTxt3.Margin = New System.Windows.Forms.Padding(2)
        Me.CreditAmountTxt3.Name = "CreditAmountTxt3"
        Me.CreditAmountTxt3.Size = New System.Drawing.Size(76, 20)
        Me.CreditAmountTxt3.TabIndex = 198
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.BackColor = System.Drawing.Color.Transparent
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(571, 242)
        Me.Label55.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(84, 13)
        Me.Label55.TabIndex = 199
        Me.Label55.Text = "COLLECTION"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.BackColor = System.Drawing.Color.Transparent
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(581, 264)
        Me.Label56.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(64, 13)
        Me.Label56.TabIndex = 200
        Me.Label56.Text = "AMOUNT:"
        '
        'CollAmountTxt3
        '
        Me.CollAmountTxt3.Location = New System.Drawing.Point(645, 307)
        Me.CollAmountTxt3.Margin = New System.Windows.Forms.Padding(2)
        Me.CollAmountTxt3.Name = "CollAmountTxt3"
        Me.CollAmountTxt3.Size = New System.Drawing.Size(76, 20)
        Me.CollAmountTxt3.TabIndex = 203
        '
        'CollAmountTxt2
        '
        Me.CollAmountTxt2.Location = New System.Drawing.Point(645, 285)
        Me.CollAmountTxt2.Margin = New System.Windows.Forms.Padding(2)
        Me.CollAmountTxt2.Name = "CollAmountTxt2"
        Me.CollAmountTxt2.Size = New System.Drawing.Size(76, 20)
        Me.CollAmountTxt2.TabIndex = 202
        '
        'CollAmountTxt1
        '
        Me.CollAmountTxt1.Location = New System.Drawing.Point(645, 262)
        Me.CollAmountTxt1.Margin = New System.Windows.Forms.Padding(2)
        Me.CollAmountTxt1.Name = "CollAmountTxt1"
        Me.CollAmountTxt1.Size = New System.Drawing.Size(76, 20)
        Me.CollAmountTxt1.TabIndex = 201
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.BackColor = System.Drawing.Color.Transparent
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(581, 11)
        Me.Label57.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(206, 17)
        Me.Label57.TabIndex = 204
        Me.Label57.Text = "CASH REMITTANCE COMP." & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.BackColor = System.Drawing.Color.Transparent
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(844, 11)
        Me.Label58.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(153, 17)
        Me.Label58.TabIndex = 206
        Me.Label58.Text = "CASH BREAKDOWN" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.BackColor = System.Drawing.Color.Transparent
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.Blue
        Me.Label59.Location = New System.Drawing.Point(799, 35)
        Me.Label59.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(48, 13)
        Me.Label59.TabIndex = 207
        Me.Label59.Text = "PESOS"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.BackColor = System.Drawing.Color.Transparent
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.Blue
        Me.Label60.Location = New System.Drawing.Point(872, 35)
        Me.Label60.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(81, 13)
        Me.Label60.TabIndex = 208
        Me.Label60.Text = "NO. OF PCS."
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.BackColor = System.Drawing.Color.Transparent
        Me.Label61.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.ForeColor = System.Drawing.Color.Blue
        Me.Label61.Location = New System.Drawing.Point(966, 35)
        Me.Label61.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(60, 13)
        Me.Label61.TabIndex = 209
        Me.Label61.Text = "AMOUNT"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.BackColor = System.Drawing.Color.Transparent
        Me.Label62.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(803, 54)
        Me.Label62.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(65, 13)
        Me.Label62.TabIndex = 210
        Me.Label62.Text = " 1,000.00 "
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.BackColor = System.Drawing.Color.Transparent
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(803, 77)
        Me.Label63.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(54, 13)
        Me.Label63.TabIndex = 211
        Me.Label63.Text = " 500.00 "
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.BackColor = System.Drawing.Color.Transparent
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(803, 99)
        Me.Label64.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(54, 13)
        Me.Label64.TabIndex = 212
        Me.Label64.Text = " 200.00 "
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.BackColor = System.Drawing.Color.Transparent
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(803, 190)
        Me.Label65.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(47, 13)
        Me.Label65.TabIndex = 216
        Me.Label65.Text = " 10.00 "
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.BackColor = System.Drawing.Color.Transparent
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(803, 168)
        Me.Label66.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(47, 13)
        Me.Label66.TabIndex = 215
        Me.Label66.Text = " 20.00 "
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.BackColor = System.Drawing.Color.Transparent
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(803, 145)
        Me.Label67.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(47, 13)
        Me.Label67.TabIndex = 214
        Me.Label67.Text = " 50.00 "
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.BackColor = System.Drawing.Color.Transparent
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(803, 122)
        Me.Label68.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(54, 13)
        Me.Label68.TabIndex = 213
        Me.Label68.Text = " 100.00 "
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.BackColor = System.Drawing.Color.Transparent
        Me.Label69.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(803, 213)
        Me.Label69.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(40, 13)
        Me.Label69.TabIndex = 217
        Me.Label69.Text = " 5.00 "
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.BackColor = System.Drawing.Color.Transparent
        Me.Label70.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(803, 236)
        Me.Label70.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(45, 13)
        Me.Label70.TabIndex = 218
        Me.Label70.Text = "COINS"
        '
        'ThousandsTxt
        '
        Me.ThousandsTxt.Location = New System.Drawing.Point(872, 51)
        Me.ThousandsTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.ThousandsTxt.Name = "ThousandsTxt"
        Me.ThousandsTxt.Size = New System.Drawing.Size(76, 20)
        Me.ThousandsTxt.TabIndex = 219
        '
        'FiveHundTxt
        '
        Me.FiveHundTxt.Location = New System.Drawing.Point(872, 74)
        Me.FiveHundTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FiveHundTxt.Name = "FiveHundTxt"
        Me.FiveHundTxt.Size = New System.Drawing.Size(76, 20)
        Me.FiveHundTxt.TabIndex = 220
        '
        'OneHundTxt
        '
        Me.OneHundTxt.Location = New System.Drawing.Point(872, 119)
        Me.OneHundTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.OneHundTxt.Name = "OneHundTxt"
        Me.OneHundTxt.Size = New System.Drawing.Size(76, 20)
        Me.OneHundTxt.TabIndex = 222
        '
        'TwoHundTxt
        '
        Me.TwoHundTxt.Location = New System.Drawing.Point(872, 97)
        Me.TwoHundTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.TwoHundTxt.Name = "TwoHundTxt"
        Me.TwoHundTxt.Size = New System.Drawing.Size(76, 20)
        Me.TwoHundTxt.TabIndex = 221
        '
        'TwentTxt
        '
        Me.TwentTxt.Location = New System.Drawing.Point(872, 165)
        Me.TwentTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.TwentTxt.Name = "TwentTxt"
        Me.TwentTxt.Size = New System.Drawing.Size(76, 20)
        Me.TwentTxt.TabIndex = 224
        '
        'FiftyTxt
        '
        Me.FiftyTxt.Location = New System.Drawing.Point(872, 142)
        Me.FiftyTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FiftyTxt.Name = "FiftyTxt"
        Me.FiftyTxt.Size = New System.Drawing.Size(76, 20)
        Me.FiftyTxt.TabIndex = 223
        '
        'FiveTxt
        '
        Me.FiveTxt.Location = New System.Drawing.Point(872, 211)
        Me.FiveTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FiveTxt.Name = "FiveTxt"
        Me.FiveTxt.Size = New System.Drawing.Size(76, 20)
        Me.FiveTxt.TabIndex = 226
        '
        'TenTxt
        '
        Me.TenTxt.Location = New System.Drawing.Point(872, 188)
        Me.TenTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.TenTxt.Name = "TenTxt"
        Me.TenTxt.Size = New System.Drawing.Size(76, 20)
        Me.TenTxt.TabIndex = 225
        '
        'CoinsTxt
        '
        Me.CoinsTxt.Location = New System.Drawing.Point(872, 233)
        Me.CoinsTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.CoinsTxt.Name = "CoinsTxt"
        Me.CoinsTxt.Size = New System.Drawing.Size(134, 20)
        Me.CoinsTxt.TabIndex = 227
        '
        'ThousandsLbl
        '
        Me.ThousandsLbl.AutoSize = True
        Me.ThousandsLbl.BackColor = System.Drawing.Color.Transparent
        Me.ThousandsLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ThousandsLbl.Location = New System.Drawing.Point(967, 51)
        Me.ThousandsLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ThousandsLbl.Name = "ThousandsLbl"
        Me.ThousandsLbl.Size = New System.Drawing.Size(39, 13)
        Me.ThousandsLbl.TabIndex = 228
        Me.ThousandsLbl.Text = "00.00"
        '
        'FiveHundLbl
        '
        Me.FiveHundLbl.AutoSize = True
        Me.FiveHundLbl.BackColor = System.Drawing.Color.Transparent
        Me.FiveHundLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiveHundLbl.Location = New System.Drawing.Point(967, 75)
        Me.FiveHundLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FiveHundLbl.Name = "FiveHundLbl"
        Me.FiveHundLbl.Size = New System.Drawing.Size(39, 13)
        Me.FiveHundLbl.TabIndex = 229
        Me.FiveHundLbl.Text = "00.00"
        '
        'OneHundLbl
        '
        Me.OneHundLbl.AutoSize = True
        Me.OneHundLbl.BackColor = System.Drawing.Color.Transparent
        Me.OneHundLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OneHundLbl.Location = New System.Drawing.Point(967, 120)
        Me.OneHundLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.OneHundLbl.Name = "OneHundLbl"
        Me.OneHundLbl.Size = New System.Drawing.Size(39, 13)
        Me.OneHundLbl.TabIndex = 231
        Me.OneHundLbl.Text = "00.00"
        '
        'TwoHundLbl
        '
        Me.TwoHundLbl.AutoSize = True
        Me.TwoHundLbl.BackColor = System.Drawing.Color.Transparent
        Me.TwoHundLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TwoHundLbl.Location = New System.Drawing.Point(967, 95)
        Me.TwoHundLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.TwoHundLbl.Name = "TwoHundLbl"
        Me.TwoHundLbl.Size = New System.Drawing.Size(39, 13)
        Me.TwoHundLbl.TabIndex = 230
        Me.TwoHundLbl.Text = "00.00"
        '
        'TenLbl
        '
        Me.TenLbl.AutoSize = True
        Me.TenLbl.BackColor = System.Drawing.Color.Transparent
        Me.TenLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TenLbl.Location = New System.Drawing.Point(967, 190)
        Me.TenLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.TenLbl.Name = "TenLbl"
        Me.TenLbl.Size = New System.Drawing.Size(39, 13)
        Me.TenLbl.TabIndex = 234
        Me.TenLbl.Text = "00.00"
        '
        'TwentLbl
        '
        Me.TwentLbl.AutoSize = True
        Me.TwentLbl.BackColor = System.Drawing.Color.Transparent
        Me.TwentLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TwentLbl.Location = New System.Drawing.Point(967, 165)
        Me.TwentLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.TwentLbl.Name = "TwentLbl"
        Me.TwentLbl.Size = New System.Drawing.Size(39, 13)
        Me.TwentLbl.TabIndex = 233
        Me.TwentLbl.Text = "00.00"
        '
        'FiftyLbl
        '
        Me.FiftyLbl.AutoSize = True
        Me.FiftyLbl.BackColor = System.Drawing.Color.Transparent
        Me.FiftyLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiftyLbl.Location = New System.Drawing.Point(967, 145)
        Me.FiftyLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FiftyLbl.Name = "FiftyLbl"
        Me.FiftyLbl.Size = New System.Drawing.Size(39, 13)
        Me.FiftyLbl.TabIndex = 232
        Me.FiftyLbl.Text = "00.00"
        '
        'FiveLbl
        '
        Me.FiveLbl.AutoSize = True
        Me.FiveLbl.BackColor = System.Drawing.Color.Transparent
        Me.FiveLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiveLbl.Location = New System.Drawing.Point(967, 213)
        Me.FiveLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FiveLbl.Name = "FiveLbl"
        Me.FiveLbl.Size = New System.Drawing.Size(39, 13)
        Me.FiveLbl.TabIndex = 235
        Me.FiveLbl.Text = "00.00"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.BackColor = System.Drawing.Color.Transparent
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(803, 277)
        Me.Label79.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(40, 13)
        Me.Label79.TabIndex = 236
        Me.Label79.Text = "BANK"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.BackColor = System.Drawing.Color.Transparent
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(805, 300)
        Me.Label80.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(64, 13)
        Me.Label80.TabIndex = 237
        Me.Label80.Text = "AMOUNT:"
        '
        'BankAmountTxt3
        '
        Me.BankAmountTxt3.Location = New System.Drawing.Point(873, 344)
        Me.BankAmountTxt3.Margin = New System.Windows.Forms.Padding(2)
        Me.BankAmountTxt3.Name = "BankAmountTxt3"
        Me.BankAmountTxt3.Size = New System.Drawing.Size(76, 20)
        Me.BankAmountTxt3.TabIndex = 240
        '
        'BankAmountTxt2
        '
        Me.BankAmountTxt2.Location = New System.Drawing.Point(873, 321)
        Me.BankAmountTxt2.Margin = New System.Windows.Forms.Padding(2)
        Me.BankAmountTxt2.Name = "BankAmountTxt2"
        Me.BankAmountTxt2.Size = New System.Drawing.Size(76, 20)
        Me.BankAmountTxt2.TabIndex = 239
        '
        'BankAmountTxt1
        '
        Me.BankAmountTxt1.Location = New System.Drawing.Point(873, 298)
        Me.BankAmountTxt1.Margin = New System.Windows.Forms.Padding(2)
        Me.BankAmountTxt1.Name = "BankAmountTxt1"
        Me.BankAmountTxt1.Size = New System.Drawing.Size(76, 20)
        Me.BankAmountTxt1.TabIndex = 238
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.BackColor = System.Drawing.Color.Transparent
        Me.Label81.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.ForeColor = System.Drawing.Color.Yellow
        Me.Label81.Location = New System.Drawing.Point(803, 403)
        Me.Label81.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(131, 13)
        Me.Label81.TabIndex = 241
        Me.Label81.Text = "TOTAL REMITTANCE"
        '
        'ShortLbl
        '
        Me.ShortLbl.AutoSize = True
        Me.ShortLbl.BackColor = System.Drawing.Color.Transparent
        Me.ShortLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ShortLbl.ForeColor = System.Drawing.Color.Yellow
        Me.ShortLbl.Location = New System.Drawing.Point(805, 469)
        Me.ShortLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ShortLbl.Name = "ShortLbl"
        Me.ShortLbl.Size = New System.Drawing.Size(50, 13)
        Me.ShortLbl.TabIndex = 242
        Me.ShortLbl.Text = "SHORT"
        '
        'OverLbl
        '
        Me.OverLbl.AutoSize = True
        Me.OverLbl.BackColor = System.Drawing.Color.Transparent
        Me.OverLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OverLbl.ForeColor = System.Drawing.Color.Yellow
        Me.OverLbl.Location = New System.Drawing.Point(866, 469)
        Me.OverLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.OverLbl.Name = "OverLbl"
        Me.OverLbl.Size = New System.Drawing.Size(41, 13)
        Me.OverLbl.TabIndex = 243
        Me.OverLbl.Text = "OVER"
        '
        'TotalRemitAmountLbl
        '
        Me.TotalRemitAmountLbl.AutoSize = True
        Me.TotalRemitAmountLbl.BackColor = System.Drawing.Color.Transparent
        Me.TotalRemitAmountLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalRemitAmountLbl.Location = New System.Drawing.Point(817, 434)
        Me.TotalRemitAmountLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.TotalRemitAmountLbl.Name = "TotalRemitAmountLbl"
        Me.TotalRemitAmountLbl.Size = New System.Drawing.Size(207, 24)
        Me.TotalRemitAmountLbl.TabIndex = 244
        Me.TotalRemitAmountLbl.Text = "Click To See Amount"
        '
        'SOLbl
        '
        Me.SOLbl.AutoSize = True
        Me.SOLbl.BackColor = System.Drawing.Color.Transparent
        Me.SOLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SOLbl.Location = New System.Drawing.Point(817, 489)
        Me.SOLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.SOLbl.Name = "SOLbl"
        Me.SOLbl.Size = New System.Drawing.Size(207, 24)
        Me.SOLbl.TabIndex = 245
        Me.SOLbl.Text = "Click To See Amount"
        '
        'ClearAllTxtBtn
        '
        Me.ClearAllTxtBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearAllTxtBtn.Location = New System.Drawing.Point(321, 49)
        Me.ClearAllTxtBtn.Margin = New System.Windows.Forms.Padding(2)
        Me.ClearAllTxtBtn.Name = "ClearAllTxtBtn"
        Me.ClearAllTxtBtn.Size = New System.Drawing.Size(87, 33)
        Me.ClearAllTxtBtn.TabIndex = 246
        Me.ClearAllTxtBtn.Text = "Clear All"
        Me.ClearAllTxtBtn.UseVisualStyleBackColor = True
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.BackColor = System.Drawing.Color.Transparent
        Me.Label71.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.ForeColor = System.Drawing.Color.Yellow
        Me.Label71.Location = New System.Drawing.Point(853, 470)
        Me.Label71.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(13, 13)
        Me.Label71.TabIndex = 247
        Me.Label71.Text = "/"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.BackColor = System.Drawing.Color.Transparent
        Me.Label72.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.ForeColor = System.Drawing.Color.Black
        Me.Label72.Location = New System.Drawing.Point(10, 514)
        Me.Label72.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(72, 13)
        Me.Label72.TabIndex = 248
        Me.Label72.Text = "PAMC/SDC"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.BackColor = System.Drawing.Color.Transparent
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.ForeColor = System.Drawing.Color.Black
        Me.Label73.Location = New System.Drawing.Point(10, 538)
        Me.Label73.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(32, 13)
        Me.Label73.TabIndex = 249
        Me.Label73.Text = "KRC"
        '
        'KrcTxt
        '
        Me.KrcTxt.Location = New System.Drawing.Point(98, 535)
        Me.KrcTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.KrcTxt.Name = "KrcTxt"
        Me.KrcTxt.Size = New System.Drawing.Size(76, 20)
        Me.KrcTxt.TabIndex = 251
        '
        'PamcLbl
        '
        Me.PamcLbl.AutoSize = True
        Me.PamcLbl.BackColor = System.Drawing.Color.Transparent
        Me.PamcLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PamcLbl.ForeColor = System.Drawing.Color.Black
        Me.PamcLbl.Location = New System.Drawing.Point(202, 514)
        Me.PamcLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PamcLbl.Name = "PamcLbl"
        Me.PamcLbl.Size = New System.Drawing.Size(39, 13)
        Me.PamcLbl.TabIndex = 252
        Me.PamcLbl.Text = "00.00"
        '
        'KrcLbl
        '
        Me.KrcLbl.AutoSize = True
        Me.KrcLbl.BackColor = System.Drawing.Color.Transparent
        Me.KrcLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KrcLbl.ForeColor = System.Drawing.Color.Black
        Me.KrcLbl.Location = New System.Drawing.Point(202, 538)
        Me.KrcLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.KrcLbl.Name = "KrcLbl"
        Me.KrcLbl.Size = New System.Drawing.Size(39, 13)
        Me.KrcLbl.TabIndex = 253
        Me.KrcLbl.Text = "00.00"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.BackColor = System.Drawing.Color.Transparent
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.ForeColor = System.Drawing.Color.Black
        Me.Label74.Location = New System.Drawing.Point(10, 562)
        Me.Label74.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(32, 13)
        Me.Label74.TabIndex = 254
        Me.Label74.Text = "HSC"
        '
        'HscTxt
        '
        Me.HscTxt.Location = New System.Drawing.Point(98, 559)
        Me.HscTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.HscTxt.Name = "HscTxt"
        Me.HscTxt.Size = New System.Drawing.Size(76, 20)
        Me.HscTxt.TabIndex = 255
        '
        'HscLbl
        '
        Me.HscLbl.AutoSize = True
        Me.HscLbl.BackColor = System.Drawing.Color.Transparent
        Me.HscLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HscLbl.ForeColor = System.Drawing.Color.Black
        Me.HscLbl.Location = New System.Drawing.Point(202, 562)
        Me.HscLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.HscLbl.Name = "HscLbl"
        Me.HscLbl.Size = New System.Drawing.Size(39, 13)
        Me.HscLbl.TabIndex = 256
        Me.HscLbl.Text = "00.00"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.BackColor = System.Drawing.Color.Transparent
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.ForeColor = System.Drawing.Color.Black
        Me.Label76.Location = New System.Drawing.Point(10, 586)
        Me.Label76.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(73, 13)
        Me.Label76.TabIndex = 257
        Me.Label76.Text = "SML BOTT."
        '
        'SmlbBottTxt
        '
        Me.SmlbBottTxt.Location = New System.Drawing.Point(98, 583)
        Me.SmlbBottTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.SmlbBottTxt.Name = "SmlbBottTxt"
        Me.SmlbBottTxt.Size = New System.Drawing.Size(76, 20)
        Me.SmlbBottTxt.TabIndex = 258
        '
        'SmlbBottLbl
        '
        Me.SmlbBottLbl.AutoSize = True
        Me.SmlbBottLbl.BackColor = System.Drawing.Color.Transparent
        Me.SmlbBottLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SmlbBottLbl.ForeColor = System.Drawing.Color.Black
        Me.SmlbBottLbl.Location = New System.Drawing.Point(202, 586)
        Me.SmlbBottLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.SmlbBottLbl.Name = "SmlbBottLbl"
        Me.SmlbBottLbl.Size = New System.Drawing.Size(39, 13)
        Me.SmlbBottLbl.TabIndex = 259
        Me.SmlbBottLbl.Text = "00.00"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.BackColor = System.Drawing.Color.Transparent
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.ForeColor = System.Drawing.Color.Black
        Me.Label75.Location = New System.Drawing.Point(11, 613)
        Me.Label75.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(40, 13)
        Me.Label75.TabIndex = 260
        Me.Label75.Text = "SMFB"
        '
        'SmfbTxt
        '
        Me.SmfbTxt.Location = New System.Drawing.Point(98, 607)
        Me.SmfbTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.SmfbTxt.Name = "SmfbTxt"
        Me.SmfbTxt.Size = New System.Drawing.Size(76, 20)
        Me.SmfbTxt.TabIndex = 261
        '
        'SmfbLbl
        '
        Me.SmfbLbl.AutoSize = True
        Me.SmfbLbl.BackColor = System.Drawing.Color.Transparent
        Me.SmfbLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SmfbLbl.ForeColor = System.Drawing.Color.Black
        Me.SmfbLbl.Location = New System.Drawing.Point(202, 610)
        Me.SmfbLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.SmfbLbl.Name = "SmfbLbl"
        Me.SmfbLbl.Size = New System.Drawing.Size(39, 13)
        Me.SmfbLbl.TabIndex = 262
        Me.SmfbLbl.Text = "00.00"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.BackColor = System.Drawing.Color.Transparent
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.ForeColor = System.Drawing.Color.Black
        Me.Label77.Location = New System.Drawing.Point(10, 634)
        Me.Label77.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(40, 13)
        Me.Label77.TabIndex = 263
        Me.Label77.Text = "SMFC"
        '
        'SmfcTxt
        '
        Me.SmfcTxt.Location = New System.Drawing.Point(98, 631)
        Me.SmfcTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.SmfcTxt.Name = "SmfcTxt"
        Me.SmfcTxt.Size = New System.Drawing.Size(76, 20)
        Me.SmfcTxt.TabIndex = 264
        '
        'SmfcLbl
        '
        Me.SmfcLbl.AutoSize = True
        Me.SmfcLbl.BackColor = System.Drawing.Color.Transparent
        Me.SmfcLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SmfcLbl.ForeColor = System.Drawing.Color.Black
        Me.SmfcLbl.Location = New System.Drawing.Point(202, 634)
        Me.SmfcLbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.SmfcLbl.Name = "SmfcLbl"
        Me.SmfcLbl.Size = New System.Drawing.Size(39, 13)
        Me.SmfcLbl.TabIndex = 265
        Me.SmfcLbl.Text = "00.00"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.ReturnSku3Txt)
        Me.Panel1.Controls.Add(Me.ReturnSku2Txt)
        Me.Panel1.Controls.Add(Me.Label82)
        Me.Panel1.Controls.Add(Me.ReturnSku1Txt)
        Me.Panel1.Controls.Add(Me.Label78)
        Me.Panel1.Controls.Add(Me.ClearAllTxtBtn)
        Me.Panel1.Location = New System.Drawing.Point(282, 574)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(715, 158)
        Me.Panel1.TabIndex = 266
        '
        'PamcTxt
        '
        Me.PamcTxt.Location = New System.Drawing.Point(98, 511)
        Me.PamcTxt.Margin = New System.Windows.Forms.Padding(2)
        Me.PamcTxt.Name = "PamcTxt"
        Me.PamcTxt.Size = New System.Drawing.Size(76, 20)
        Me.PamcTxt.TabIndex = 267
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.ForeColor = System.Drawing.Color.Red
        Me.Label78.Location = New System.Drawing.Point(9, 11)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(125, 20)
        Me.Label78.TabIndex = 247
        Me.Label78.Text = "Returned SKU"
        '
        'ReturnSku1Txt
        '
        Me.ReturnSku1Txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnSku1Txt.Location = New System.Drawing.Point(26, 56)
        Me.ReturnSku1Txt.Name = "ReturnSku1Txt"
        Me.ReturnSku1Txt.Size = New System.Drawing.Size(100, 26)
        Me.ReturnSku1Txt.TabIndex = 248
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(22, 33)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(69, 20)
        Me.Label82.TabIndex = 249
        Me.Label82.Text = "Amount:"
        '
        'ReturnSku2Txt
        '
        Me.ReturnSku2Txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnSku2Txt.Location = New System.Drawing.Point(26, 88)
        Me.ReturnSku2Txt.Name = "ReturnSku2Txt"
        Me.ReturnSku2Txt.Size = New System.Drawing.Size(100, 26)
        Me.ReturnSku2Txt.TabIndex = 250
        '
        'ReturnSku3Txt
        '
        Me.ReturnSku3Txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnSku3Txt.Location = New System.Drawing.Point(26, 120)
        Me.ReturnSku3Txt.Name = "ReturnSku3Txt"
        Me.ReturnSku3Txt.Size = New System.Drawing.Size(100, 26)
        Me.ReturnSku3Txt.TabIndex = 251
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DarkRed
        Me.Panel2.Controls.Add(Me.Label83)
        Me.Panel2.Location = New System.Drawing.Point(0, 769)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1038, 56)
        Me.Panel2.TabIndex = 268
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("MidnightSnack BB", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.ForeColor = System.Drawing.Color.White
        Me.Label83.Location = New System.Drawing.Point(371, 14)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(311, 32)
        Me.Label83.TabIndex = 0
        Me.Label83.Text = "©GBDS 2025"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(1038, 824)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.PamcTxt)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.SmfcLbl)
        Me.Controls.Add(Me.SmfcTxt)
        Me.Controls.Add(Me.Label77)
        Me.Controls.Add(Me.SmfbLbl)
        Me.Controls.Add(Me.SmfbTxt)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.SmlbBottLbl)
        Me.Controls.Add(Me.SmlbBottTxt)
        Me.Controls.Add(Me.Label76)
        Me.Controls.Add(Me.HscLbl)
        Me.Controls.Add(Me.HscTxt)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.KrcLbl)
        Me.Controls.Add(Me.PamcLbl)
        Me.Controls.Add(Me.KrcTxt)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Label72)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.SOLbl)
        Me.Controls.Add(Me.TotalRemitAmountLbl)
        Me.Controls.Add(Me.OverLbl)
        Me.Controls.Add(Me.ShortLbl)
        Me.Controls.Add(Me.Label81)
        Me.Controls.Add(Me.BankAmountTxt3)
        Me.Controls.Add(Me.BankAmountTxt2)
        Me.Controls.Add(Me.BankAmountTxt1)
        Me.Controls.Add(Me.Label80)
        Me.Controls.Add(Me.Label79)
        Me.Controls.Add(Me.FiveLbl)
        Me.Controls.Add(Me.TenLbl)
        Me.Controls.Add(Me.TwentLbl)
        Me.Controls.Add(Me.FiftyLbl)
        Me.Controls.Add(Me.OneHundLbl)
        Me.Controls.Add(Me.TwoHundLbl)
        Me.Controls.Add(Me.FiveHundLbl)
        Me.Controls.Add(Me.ThousandsLbl)
        Me.Controls.Add(Me.CoinsTxt)
        Me.Controls.Add(Me.FiveTxt)
        Me.Controls.Add(Me.TenTxt)
        Me.Controls.Add(Me.TwentTxt)
        Me.Controls.Add(Me.FiftyTxt)
        Me.Controls.Add(Me.OneHundTxt)
        Me.Controls.Add(Me.TwoHundTxt)
        Me.Controls.Add(Me.FiveHundTxt)
        Me.Controls.Add(Me.ThousandsTxt)
        Me.Controls.Add(Me.Label70)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.Label65)
        Me.Controls.Add(Me.Label66)
        Me.Controls.Add(Me.Label67)
        Me.Controls.Add(Me.Label68)
        Me.Controls.Add(Me.Label64)
        Me.Controls.Add(Me.Label63)
        Me.Controls.Add(Me.Label62)
        Me.Controls.Add(Me.Label61)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.Label58)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.CollAmountTxt3)
        Me.Controls.Add(Me.CollAmountTxt2)
        Me.Controls.Add(Me.CollAmountTxt1)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.CreditAmountTxt3)
        Me.Controls.Add(Me.CreditAmountTxt2)
        Me.Controls.Add(Me.CreditAmountTxt1)
        Me.Controls.Add(Me.AmountRemittedLbl)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.PromoTxt)
        Me.Controls.Add(Me.TolFTxt)
        Me.Controls.Add(Me.DiscTxt)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.GrossSalesLbl)
        Me.Controls.Add(Me.TotalContRetLbl)
        Me.Controls.Add(Me.TotalSalesLbl)
        Me.Controls.Add(Me.MhtBottleLbl)
        Me.Controls.Add(Me.MhtShellLbl)
        Me.Controls.Add(Me.MhtCompLbl)
        Me.Controls.Add(Me.FbaBottleLbl)
        Me.Controls.Add(Me.FbaShellLbl)
        Me.Controls.Add(Me.FbaCompLbl)
        Me.Controls.Add(Me.RhpBottleLbl)
        Me.Controls.Add(Me.RhpShellLbl)
        Me.Controls.Add(Me.RhpCompLbl)
        Me.Controls.Add(Me.RhlBottleLbl)
        Me.Controls.Add(Me.RhlShellLbl)
        Me.Controls.Add(Me.RhlCompLbl)
        Me.Controls.Add(Me.PpBottleLbl)
        Me.Controls.Add(Me.PpShellLbl)
        Me.Controls.Add(Me.PpCompLbl)
        Me.Controls.Add(Me.MhtBottleTxt)
        Me.Controls.Add(Me.MhtShellTxt)
        Me.Controls.Add(Me.MhtCompTxt)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.FbaBottleTxt)
        Me.Controls.Add(Me.FbaShellTxt)
        Me.Controls.Add(Me.FbaCompTxt)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.RhpBottleTxt)
        Me.Controls.Add(Me.RhpShellTxt)
        Me.Controls.Add(Me.RhpCompTxt)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.RhlBottleTxt)
        Me.Controls.Add(Me.RhlShellTxt)
        Me.Controls.Add(Me.RhlCompTxt)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.PpBottleTxt)
        Me.Controls.Add(Me.PpShellTxt)
        Me.Controls.Add(Me.PpCompTxt)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.ChocLagLbl)
        Me.Controls.Add(Me.FbBottLbl)
        Me.Controls.Add(Me.RhslBottLbl)
        Me.Controls.Add(Me.RhslLbl)
        Me.Controls.Add(Me.PlBottLbl)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.ChocLagTxt)
        Me.Controls.Add(Me.FbBottTxt)
        Me.Controls.Add(Me.RhslBottTxt)
        Me.Controls.Add(Me.RhslTxt)
        Me.Controls.Add(Me.PlBottTxt)
        Me.Controls.Add(Me.GekLbl)
        Me.Controls.Add(Me.CcLbl)
        Me.Controls.Add(Me.PpcLbl)
        Me.Controls.Add(Me.FbcLbl)
        Me.Controls.Add(Me.CnbLbl)
        Me.Controls.Add(Me.CbLbl)
        Me.Controls.Add(Me.MhtBottLbl)
        Me.Controls.Add(Me.MhtLbl)
        Me.Controls.Add(Me.FbLbl)
        Me.Controls.Add(Me.SmlbLbl)
        Me.Controls.Add(Me.Pp320Lbl)
        Me.Controls.Add(Me.PlLbl)
        Me.Controls.Add(Me.RhsLbl)
        Me.Controls.Add(Me.GekTxt)
        Me.Controls.Add(Me.CcTxt)
        Me.Controls.Add(Me.PpcTxt)
        Me.Controls.Add(Me.FbcTxt)
        Me.Controls.Add(Me.CnbTxt)
        Me.Controls.Add(Me.CbTxt)
        Me.Controls.Add(Me.MhtBottTxt)
        Me.Controls.Add(Me.MhtTxt)
        Me.Controls.Add(Me.FbTxt)
        Me.Controls.Add(Me.SmlbTxt)
        Me.Controls.Add(Me.Pp320Txt)
        Me.Controls.Add(Me.PlTxt)
        Me.Controls.Add(Me.RhsTxt)
        Me.Controls.Add(Me.RhpLbl)
        Me.Controls.Add(Me.RhpTxt)
        Me.Controls.Add(Me.RhlTxt)
        Me.Controls.Add(Me.RhlLbl)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GBDS (SALES AND CASH REMITTANCE REPORT)"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents RhlLbl As Label
    Friend WithEvents RhlTxt As TextBox
    Friend WithEvents RhpTxt As TextBox
    Friend WithEvents RhpLbl As Label
    Friend WithEvents PlTxt As TextBox
    Friend WithEvents RhsTxt As TextBox
    Friend WithEvents SmlbTxt As TextBox
    Friend WithEvents Pp320Txt As TextBox
    Friend WithEvents MhtTxt As TextBox
    Friend WithEvents FbTxt As TextBox
    Friend WithEvents CbTxt As TextBox
    Friend WithEvents MhtBottTxt As TextBox
    Friend WithEvents FbcTxt As TextBox
    Friend WithEvents CnbTxt As TextBox
    Friend WithEvents CcTxt As TextBox
    Friend WithEvents PpcTxt As TextBox
    Friend WithEvents GekTxt As TextBox
    Friend WithEvents PlLbl As Label
    Friend WithEvents RhsLbl As Label
    Friend WithEvents SmlbLbl As Label
    Friend WithEvents Pp320Lbl As Label
    Friend WithEvents MhtLbl As Label
    Friend WithEvents FbLbl As Label
    Friend WithEvents CbLbl As Label
    Friend WithEvents MhtBottLbl As Label
    Friend WithEvents FbcLbl As Label
    Friend WithEvents CnbLbl As Label
    Friend WithEvents CcLbl As Label
    Friend WithEvents PpcLbl As Label
    Friend WithEvents GekLbl As Label
    Friend WithEvents RhslTxt As TextBox
    Friend WithEvents PlBottTxt As TextBox
    Friend WithEvents FbBottTxt As TextBox
    Friend WithEvents RhslBottTxt As TextBox
    Friend WithEvents ChocLagTxt As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents RhslLbl As Label
    Friend WithEvents PlBottLbl As Label
    Friend WithEvents FbBottLbl As Label
    Friend WithEvents RhslBottLbl As Label
    Friend WithEvents ChocLagLbl As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents PpCompTxt As TextBox
    Friend WithEvents PpShellTxt As TextBox
    Friend WithEvents PpBottleTxt As TextBox
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents RhlBottleTxt As TextBox
    Friend WithEvents RhlShellTxt As TextBox
    Friend WithEvents RhlCompTxt As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents RhpBottleTxt As TextBox
    Friend WithEvents RhpShellTxt As TextBox
    Friend WithEvents RhpCompTxt As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents FbaBottleTxt As TextBox
    Friend WithEvents FbaShellTxt As TextBox
    Friend WithEvents FbaCompTxt As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents MhtBottleTxt As TextBox
    Friend WithEvents MhtShellTxt As TextBox
    Friend WithEvents MhtCompTxt As TextBox
    Friend WithEvents PpCompLbl As Label
    Friend WithEvents PpShellLbl As Label
    Friend WithEvents PpBottleLbl As Label
    Friend WithEvents RhlBottleLbl As Label
    Friend WithEvents RhlShellLbl As Label
    Friend WithEvents RhlCompLbl As Label
    Friend WithEvents RhpBottleLbl As Label
    Friend WithEvents RhpShellLbl As Label
    Friend WithEvents RhpCompLbl As Label
    Friend WithEvents FbaBottleLbl As Label
    Friend WithEvents FbaShellLbl As Label
    Friend WithEvents FbaCompLbl As Label
    Friend WithEvents MhtBottleLbl As Label
    Friend WithEvents MhtShellLbl As Label
    Friend WithEvents MhtCompLbl As Label
    Friend WithEvents TotalSalesLbl As Label
    Friend WithEvents TotalContRetLbl As Label
    Friend WithEvents GrossSalesLbl As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents DiscTxt As TextBox
    Friend WithEvents TolFTxt As TextBox
    Friend WithEvents PromoTxt As TextBox
    Friend WithEvents Label52 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents AmountRemittedLbl As Label
    Friend WithEvents CreditAmountTxt1 As TextBox
    Friend WithEvents CreditAmountTxt2 As TextBox
    Friend WithEvents CreditAmountTxt3 As TextBox
    Friend WithEvents Label55 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents CollAmountTxt3 As TextBox
    Friend WithEvents CollAmountTxt2 As TextBox
    Friend WithEvents CollAmountTxt1 As TextBox
    Friend WithEvents Label57 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents ThousandsTxt As TextBox
    Friend WithEvents FiveHundTxt As TextBox
    Friend WithEvents OneHundTxt As TextBox
    Friend WithEvents TwoHundTxt As TextBox
    Friend WithEvents TwentTxt As TextBox
    Friend WithEvents FiftyTxt As TextBox
    Friend WithEvents FiveTxt As TextBox
    Friend WithEvents TenTxt As TextBox
    Friend WithEvents CoinsTxt As TextBox
    Friend WithEvents ThousandsLbl As Label
    Friend WithEvents FiveHundLbl As Label
    Friend WithEvents OneHundLbl As Label
    Friend WithEvents TwoHundLbl As Label
    Friend WithEvents TenLbl As Label
    Friend WithEvents TwentLbl As Label
    Friend WithEvents FiftyLbl As Label
    Friend WithEvents FiveLbl As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents BankAmountTxt3 As TextBox
    Friend WithEvents BankAmountTxt2 As TextBox
    Friend WithEvents BankAmountTxt1 As TextBox
    Friend WithEvents Label81 As Label
    Friend WithEvents ShortLbl As Label
    Friend WithEvents OverLbl As Label
    Friend WithEvents TotalRemitAmountLbl As Label
    Friend WithEvents SOLbl As Label
    Friend WithEvents ClearAllTxtBtn As Button
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents KrcTxt As TextBox
    Friend WithEvents PamcLbl As Label
    Friend WithEvents KrcLbl As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents HscTxt As TextBox
    Friend WithEvents HscLbl As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents SmlbBottTxt As TextBox
    Friend WithEvents SmlbBottLbl As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents SmfbTxt As TextBox
    Friend WithEvents SmfbLbl As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents SmfcTxt As TextBox
    Friend WithEvents SmfcLbl As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PamcTxt As TextBox
    Friend WithEvents ReturnSku3Txt As TextBox
    Friend WithEvents ReturnSku2Txt As TextBox
    Friend WithEvents Label82 As Label
    Friend WithEvents ReturnSku1Txt As TextBox
    Friend WithEvents Label78 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label83 As Label
End Class
